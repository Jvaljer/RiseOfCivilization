package Types;

/**
 * An enumerated type for all the different resources
 * @author martin
 */
public enum Resource {
	Wood,
	Stone,
	Iron,
	Gold,
}
