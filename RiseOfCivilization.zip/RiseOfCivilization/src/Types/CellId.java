package Types;

/**
 * Enumerated Type for all the possible type of cell we wanna have
 * @author abel
 */
public enum CellId {
	City,
	Plain,
	Forest,
	Mountain,
	Iron_Deposit,
}
