package Types;

public enum BuildingId {
	CityHall,
	SawMill,
	Mine,
	Quarry,
	LumberCamp,
	MinerCamp,
	QuarryWorkerCamp,
	Barrack,
	Shop,
}
