package Types;

public enum EnnemyRole {
	Wolf,
	Ork,
}
