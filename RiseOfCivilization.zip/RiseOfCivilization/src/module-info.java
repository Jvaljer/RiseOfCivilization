/**
 * @author abel
 *
 */
module RiseOfCivilization {
	requires java.desktop;
	requires java.base;
	requires java.xml;
}