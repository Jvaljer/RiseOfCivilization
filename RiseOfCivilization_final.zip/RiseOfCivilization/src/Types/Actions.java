package Types;

public enum Actions {
	Collect,
	Build_Production,
	Build_Training,
	Move,
	Shop,
	Train,
	Expand,
	LevelUp,
}
