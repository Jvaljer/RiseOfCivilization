package Types;

public enum WorkerRole {
	Worker,
	Lumberjack,
	QuarryWorker,
	Miner,
	Citizen,
	Knight
}
